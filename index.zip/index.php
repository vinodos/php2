<!DOCTYPE html>
<html>
<body>

<?php
echo "My new  PHP web site   by vinod version1!";
?>

</body>
</html
