<!DOCTYPE html>
<html>
<body>

<?php
echo "My new  PHP web site   by vinod VERSION55555!";
?>

</body>
</html
